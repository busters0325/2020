import System.IO  
import Control.Monad
import Data.List.Split

main = do  
        let list = []
        handle <- openFile "test.txt" ReadMode
        contents <- hGetContents handle
        let singlewords = words contents
            list = f singlewords
        let a = Data.List.Split.chunksOf 10 list
        print a
        hClose handle   

f :: [String] -> [Int]
f = map read

